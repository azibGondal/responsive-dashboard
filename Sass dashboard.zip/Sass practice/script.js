let toggle = document.getElementById('bars');
toggle.addEventListener('click',()=>{
    let show2 = document.getElementById("sidebar");
    show2.classList.toggle('show2')
    let show1 = document.getElementById("dashboard");
    show1.classList.toggle("show1");
})